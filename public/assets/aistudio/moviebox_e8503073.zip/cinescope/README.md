# MovieBox — desktop movie & TV discovery app (TMDB)

Electron app: home hero carousel, rows (Trending / Popular / Hindi / Anime ...), Movies / TV / Anime / Hindi browse tabs,
search with suggestions + recent searches, detail page (synopsis, cast, languages, seasons & episodes, where-to-watch,
official YouTube trailers), My List and History (stored locally).

## Run
1. Install Node.js 20+ (nodejs.org).
2. Get a free TMDB API key: themoviedb.org -> Settings -> API.
3. In this folder:  `npm install`  then  `npm start`
4. Click the gear icon and paste your key.

## Build the Windows .exe
- On Windows:  `npm run dist`  -> installer + portable exe in `dist/`
- Without Windows: push this folder to a GitHub repo; the included workflow (.github/workflows/build.yml)
  builds the .exe on GitHub Actions (Actions tab -> Build Windows exe -> download artifact).

## Notes
- Metadata/images: TMDB. Streaming availability: JustWatch (via TMDB). Keep the footer attribution.
- This app does not stream or download full movies; it links to official trailers and legal streaming services.
